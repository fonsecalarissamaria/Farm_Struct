#include "radialtree.h"
#include <stddef.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "quick_sort.h"
#define M_PI 3.14

struct radialtree;



struct radialtree
{
    struct node *raiz; //raiz da árvore radial 
    int totalRemovidos;
    int totalNos;
    int totalFilhos;
    double fatorDegAtual; // Fator de Degradação atual 
    double fatorDegMaximo;
};

struct node
{
    struct radialtree *arvoreAtual;
    bool excluido; //Verifica se foi deletado 
    struct node **filhos;
    struct node *pai;
    double x;  
    double y;
    Item item; 
};



RadialTree newRadialTree(int numSetores, double fd)
{
    struct radialtree *arvore = (struct radialtree *)malloc(sizeof(struct radialtree));
    arvore->raiz = NULL;
    arvore->fatorDegAtual = 0;
    fd = fd > 0 ? fd : 0;    // fd deve ser maior que 0
    fd = fd < 1 ? fd : 0.75; // fd deve ser menor que 1
    arvore->fatorDegMaximo = fd;
    arvore->totalFilhos = numSetores;
    arvore->totalNos = 0;
    arvore->totalRemovidos = 0;
    return arvore;
}


int getNumSetores(RadialTree T)
{
    struct radialtree *arvore = (struct radialtree *)T;
    return arvore->totalFilhos;
}


void visitaProfundidadeRadialT(RadialTree t, FvisitaNo f, void *aux)
{
    struct radialtree *arvore = (struct radialtree *)t;
    struct node *node = arvore->raiz;
    if (node != NULL)
    {
        Fila fila = criaFila();
        enqueue(fila, node);
        while (!filaVazia(fila))
        {
            node = (struct node *)dequeue(fila);
            f(node->item, node->x, node->y, aux);
            for (int i = 0; i < arvore->totalFilhos; i++)
            {
                if (node->filhos[i] != NULL)
                    enqueue(fila, node->filhos[i]);
            }
        }
    }
}

void visitaLarguraRadialT(RadialTree t, FvisitaNo f, void *aux, int *count)
{
    struct radialtree *arvore = (struct radialtree *)t;
    struct node *node = arvore->raiz;
    if (node != NULL)
    {
        Fila fila = criaFila();
        enqueue(fila, node);
        while (!filaVazia(fila))
        {
            node = (struct node *)dequeue(fila);
            f(node->item, node->x, node->y, aux);
            if (count != NULL) {
                (*count)++;
            }
            for (int i = 0; i < arvore->totalFilhos; i++)
            {
                if (node->filhos[i] != NULL)
                    enqueue(fila, node->filhos[i]);
            }
        }
    }
}



int checkSetor(Node n, double x, double y)
{
    struct node *node = (struct node *)n;

    // Calcula a inclinação da reta entre o nó e o ponto (x,y)
    double inclinacao = atan2(y - node->y, x - node->x) * 180 / M_PI;
    if (inclinacao < 0)
    {
        inclinacao += 360;
    }
    // Calcula o número do setor a partir da inclinação
    int aux = (node->arvoreAtual->totalFilhos);
    int setor = (int)(inclinacao / 360 * aux);
    // Retorna o número do setor
    //printf("Setor: %d\n", setor);
    return setor;
}

double calculaFd(RadialTree t)
{
    struct radialtree *arvore = (struct radialtree *)t;
    return (double)arvore->totalRemovidos / (double)arvore->totalNos;
}


Node _criaNode(double x, double y, Info i, RadialTree t)
{
    struct node *node = (struct node *)malloc(sizeof(struct node));
    struct radialtree *arvore = (struct radialtree *)t;
    node->item = i;
    node->x = x;
    node->y = y;
    node->excluido = false;
    node->arvoreAtual = t;
    node->pai = NULL;
    node->filhos = (struct node **)malloc(sizeof(struct node *) * arvore->totalFilhos);
    for (int j = 0; j < arvore->totalFilhos; j++)
    {
        node->filhos[j] = NULL;
    }
    return node;
}




Node insertRadialT(RadialTree t, double x, double y, Info i)
{
    //printf("Info i: %p\n", i);
    struct node *node = (struct node *)malloc(sizeof(struct node));
    struct radialtree *arvore = (struct radialtree *)t;
    node->x = x;
    node->y = y;
    node->excluido = false;
    node->arvoreAtual = t;
    node->item = i;
    node->filhos = (struct node **)malloc(sizeof(struct node *) * arvore->totalFilhos);
    for (int i = 0; i < arvore->totalFilhos; i++)
    {
        node->filhos[i] = NULL;
    }
    
    if (arvore->raiz == NULL)
    {
        arvore->raiz = node;
        arvore->totalNos++;
        return node;
    }
    
    int setorRaiz = checkSetor(arvore->raiz, x, y);
    struct node *current = arvore->raiz;
    
    while (current->filhos[setorRaiz] != NULL)
    {
        current = current->filhos[setorRaiz];
        setorRaiz = checkSetor(current, x, y);
    }
    
    current->filhos[setorRaiz] = node;
    node->pai = current;
    node->arvoreAtual = arvore;
    arvore->totalNos++;
    return node;
}



Node _getRecursivo(Node n, double x, double y, double epsilon)
{
    struct node *node = (struct node *)n;
    if (node == NULL)
    {
        return NULL;
    }
    if (x >= node->x - epsilon && x <= node->x + epsilon && y >= node->y - epsilon && y <= node->y + epsilon)
    {
        return node;
    }
    else
    {
        int setor = checkSetor(node, x, y);
        return _getRecursivo(node->filhos[setor], x, y, epsilon);
    }
}


Node getNodeRadialT(RadialTree t, double x, double y, double epsilon)
{
    struct radialtree *arvore = (struct radialtree *)t;
    return _getRecursivo(arvore->raiz, x, y, epsilon);
}

void copiaArvore(Node n, struct radialtree *novaArvore, Node pai)
{
    struct node *node = (struct node *)n;
    if (node != NULL)
    {
        if (!node->excluido)
        {
            // Insere o nó na nova árvore
            //Node novoNo = insertRadialT(novaArvore, node->x, node->y, node->item);
            
            // Atualiza o pai do nó na nova árvore
            struct node *novoNo = insertRadialT(novaArvore, node->x, node->y, node->item);
            if (pai != NULL) 
            {
                struct node *paiNode = (struct node *)pai;
                if (paiNode->filhos != NULL) {
                    // Encontre a posição do nó recém-inserido nos filhos do pai
                    int posicao = -1;
                    for (int i = 0; i < paiNode->filhos; i++)    //****
                    {
                        if (paiNode->filhos[i] == NULL) {
                            posicao = i;
                            break;
                        }
                    }

                    // Atualize o pai do nó recém-inserido
                    if (posicao != -1) {
                        paiNode->filhos[posicao] = novoNo;
                    }
                }
            }

            for (int i = 0; i < novaArvore->totalFilhos; i++)
            {
                if (node->filhos[i] != NULL)
                    copiaArvore(node->filhos[i], novaArvore, novoNo);
            }
        }
    }
}


void armazenaNosValidos(Node node, Node* nosValidos, int* contador)
{
    struct node* currentNode = (struct node*)node;
    
    if (currentNode != NULL && !currentNode->excluido)
    {
        nosValidos[*contador] = node;
        (*contador)++;
    }
    
    for (int i = 0; i < currentNode->filhos; i++)
    {
        if (currentNode->filhos[i] != NULL)
        {
            armazenaNosValidos(currentNode->filhos[i], nosValidos, contador);
        }
    }
}



void _transferePraArvoreRecursivo(struct radialtree *old, struct radialtree *nova, Node n)
{
    struct node *node = (struct node *)n;
    if (node != NULL)
    {
        if (!node->excluido)
        {
            insertRadialT(nova, node->x, node->y, node->item);
        }
        for (int i = 0; i < old->totalFilhos; i++)
        {
            if (node->filhos[i] != NULL)
                _transferePraArvoreRecursivo(old, nova, node->filhos[i]);
        }
        free(node);
    }
}


void removeNoRadialT(RadialTree t, Node n)
{
    struct radialtree *arvore = (struct radialtree *)t;
    struct node *node = (struct node *)n;
    node = (struct node *)_getRecursivo(arvore->raiz, node->x, node->y, 0.01);
    if (node != NULL)
    {
        node->excluido = true;
        arvore->totalRemovidos++;
        arvore->fatorDegAtual = calculaFd(t);
        printf("Fator de degradação: %lf\n", arvore->fatorDegAtual); 
        if (arvore->fatorDegAtual > arvore->fatorDegMaximo)
        {
            printf("Fator de degradacao supera o limiar!\n\n");
            struct radialtree *novaArvore = newRadialTree(arvore->totalFilhos, arvore->fatorDegMaximo);
            _transferePraArvoreRecursivo(arvore, novaArvore, arvore->raiz);
            arvore->raiz = novaArvore->raiz;
            arvore->totalNos = novaArvore->totalNos;
            arvore->totalRemovidos = novaArvore->totalRemovidos;
            arvore->fatorDegAtual = 0;
            free(novaArvore);
        }else
        {
            printf("Fator de degradacao NÃO supera o limiar!\n\n");
        }
    }
}



void printNode(void *item, double x, double y, void *aux) {
    printf("Posição: (%lf, %lf), Info: %p\n", x, y, item);
}

void printRadialT(RadialTree t) 
{
    visitaLarguraRadialT(t, printNode, NULL, NULL);
}


Info getInfoRadialT(RadialTree t, Node n)
{
    struct node *node = (struct node *)n;
    return node->item;
}



bool getNodesDentroRegiaoRadialT(RadialTree t, double x1, double y1, double x2, double y2, Lista L)
{
    struct radialtree *arvore = (struct radialtree *)t;
    struct node *node = (struct node *)arvore->raiz;
    bool achou = false;
    if (node != NULL)
    {
        if (node->x >= x1 && node->x <= x2 && node->y >= y1 && node->y <= y2)
        {
            insertLst(L, node->item);
            achou = true;
        }
        double anguloinicial = atan2(y1 - node->y, x1 - node->x) * 180 / M_PI;
        double angulofinal = atan2(y2 - node->y, x2 - node->x) * 180 / M_PI;
        if (anguloinicial < 0) 
        {
            anguloinicial += 360;
        }

        if (angulofinal < 0) 
        {
            angulofinal += 360;
        }
        double incremento = 360 / arvore->totalFilhos;
        for (int i = 0; i < arvore->totalFilhos; i++)
        {
            double anguloFilho = incremento * i;

            // Verifica se o ângulo do filho está dentro do intervalo definido pelos ângulos inicial e final
            if (anguloinicial <= angulofinal)
            {
                if (anguloFilho >= anguloinicial && anguloFilho <= angulofinal)
                {
                    achou = achou || getNodesDentroRegiaoRadialT(t, x1, y1, x2, y2, L);
                }
            }
            else
            {
                if (anguloFilho >= anguloinicial || anguloFilho <= angulofinal)
                {
                    achou = achou || getNodesDentroRegiaoRadialT(t, x1, y1, x2, y2, L);
                }
            }
        }

    }
    return achou;
}

//////////////////////////////////////////////////////////////////////////////////////

bool getInfosDentroRegiaoRadialT(RadialTree t, double x1, double y1, double x2, double y2,
                                 FdentroDeRegiao f, Lista L, Lista *formas)
{
    struct radialtree *arvore = (struct radialtree *)t;
    struct node *node = (struct node *)arvore->raiz;
    bool achou = false;
    
    
    if (node != NULL)  
    {  
        if (f(node->item, x1, y1, x2, y2, formas))
        {
            achou = true;
            insertLst(L, node->item);  
        }

        double anguloinicial = atan2(y1 - node->y, x1 - node->x) * 180 / M_PI;
        double angulofinal = atan2(y2 - node->y, x2 - node->x) * 180 / M_PI;
        double incremento = 360 / arvore->totalFilhos;

        /*for (int i = 0; i < arvore->totalFilhos; i++)
        {
            
            double anguloFilho = anguloinicial + incremento * i;
            if (anguloFilho > 360.0)
            {
                anguloFilho -= 360.0;
            }
            
            if ((anguloFilho >= anguloinicial && anguloFilho <= angulofinal) || (anguloFilho <= angulofinal && anguloFilho >= anguloinicial))
            {
                achou = achou || getInfosDentroRegiaoRadialT(t, node->x, node->y, x2, y2, f, L, formas);   
            }
        }*/
    }
    return achou;
}

bool getInfosAtingidoPontoRadialT(RadialTree t, double x, double y, FpontoInternoAInfo f, Lista L, Lista *formas)
{
    struct radialtree *arvore = (struct radialtree *)t;
    struct node *node = (struct node *)arvore->raiz;
    bool achou = false; 
    if (node != NULL)
    {
        if (f(node->item, x, y, *formas))
        {
            achou = true;
            insertLst(L, node->item);
            printf("Achei!\n");
        }
        /*double incremento = 360 / arvore->totalFilhos;
        for (int i = 0; i < arvore->totalFilhos; i++)
        {
            double anguloFilho = incremento * i;
            double anguloPonto = atan2(y - node->y, x - node->x) * 180 / M_PI;
            if (anguloPonto < 0)
            {
                anguloPonto += 360;
            }
            int setor = (int)anguloPonto / incremento;
            if (setor == i)
            {
                achou = achou || getInfosAtingidoPontoRadialT(t, x, y, f, L, *formas);
            }
        
        }*/
    }
    return achou;
}



int countNodes(RadialTree t)
{
    struct radialtree *arvore = (struct radialtree *)t;
    return arvore->totalNos;
}

void liberaNo(struct node *node) {
    if (node == NULL) {
        return;
    }
    
    for (int i = 0; i < node->arvoreAtual->totalFilhos; i++) {
        liberaNo(node->filhos[i]);
    }
    
    free(node->filhos); // Libera o array de filhos
    
    free(node); // Libera o nó em si
}

void liberaRadialT(RadialTree tree) 
{
    struct radialtree *arvore = (struct radialtree *)tree;
    if (arvore == NULL) {
        return;
    }
    
    liberaNo(arvore->raiz); // Libera os nós da árvore radial
    
    free(arvore); // Libera a estrutura da árvore radial em si
}




/*void percorrerArvoreRadial(RadialTree t, double x, double y, double largura, double altura, Lista L) 
{
    struct radialtree* arvore = (struct radialtree*)t;
    struct node* node = (struct node*)arvore->raiz;

    double x2 = x + largura;
    double y2 = y + altura;

    if (node != NULL) 
    {
        if (node->x >= x && node->x <= x2 && node->y >= y && node->y <= y2) 
        {
            // O nó está dentro da área retangular
            insertLst(L, node->item);
            printf("O item %p está dentro da área de colheita\n", node->item); 
        }
    }
}*/


Item getItemByNode(Node node) 
{
    struct node *n = (struct node *)malloc(sizeof(struct node));

    if (node != NULL) 
    {
        return n->item;
    } else 
    {
        return NULL;
    }
}

bool getNodeExcluido(Node n)
{
    struct node *node = (struct node *)n;
    if(node->excluido == true)
    {
        return true;
    }else
    {
        return false;
    }
}

