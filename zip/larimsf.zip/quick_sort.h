#ifndef _QUICK_SORT_H
#define _QUICK_SORT_H

#include <stdbool.h>



/*
Este "contrato" provê operações básicas para implementar um Quick Sort 

O QuickSort é um algoritmo de ordenação que divide a lista em partes menores, 
usando um pivô para reorganizar os elementos. Ele repete esse processo recursivamente 
até que a lista esteja totalmente ordenada, resultando em uma classificação rápida na 
maioria dos casos.
*/


/*
 * Ordena segundo o formato do algoritmo Quick Sort 
 */
void quick_sort(void **vetor, int inicio, int fim);



#endif