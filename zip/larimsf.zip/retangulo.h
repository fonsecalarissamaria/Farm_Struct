#ifndef _RETANGULO_H
#define _RETANGULO_H

#include <stdbool.h>

//#include "lista.h"
//#include "arq_svg.h"
//typedef void* ArqSvg;

typedef void* Retangulo;


/*
Este "contrato" provê operações básicas para implementar um retângulo:  
*/



/*
    Cria um Item com as características de um retângulo 
*/
Retangulo criaRetangulo(double x, double y, double larg, double alt, int i, char *corb, char *corp);


/*
    Retorna a altura do retângulo rect
*/
double getAltura(Retangulo rect);


/*
    Retorna a largura do retângulo rect
*/
double getLargura(Retangulo rect);


/*
    Retorna a cor da borda do retângulo rect 
*/
char *getCorbRect(Retangulo rect);


/*
    Retorna a cor do preenchimento do retângulo rect 
*/
char *getCorpRect(Retangulo rect);


/*
    Retornam as posições X e Y do retângulo rect 
*/
double getPosicXRect(Retangulo rect);
double getPosicYRect(Retangulo rect);

/*
    Muda as variáveis x e/ou y do retângulo, trocando-o de posição.  
*/
void moveRetangulo(Retangulo rect, double xAntigo, double yAntigo, double dx, double dy);

void selecionaColheitadeira(Retangulo rect);
bool verificaColheitadeira(Retangulo rect);
void moveColheitadeira(Retangulo rect, char *direcao);

int getIdentificadorRetangulo(Retangulo rect); 
/* 
    Insere o estilo do retângulo 
*/
//void insereEstilo(Retangulo *R);





/*
    Coloca no relatório final qualquer tipo de movimento ou mudança relacionada ao retangulo criado 
*/
//char escreveRelatorioRetangulo(Retangulo *R); 
// char[100] = "Aconteceu tal coisa com o retangulo" 







#endif