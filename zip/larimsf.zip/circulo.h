#ifndef _CIRCULO_H
#define _CIRCULO_H

#include <stdbool.h>
//#include "lista.h"

typedef void *Circulo;


/*
Este "contrato" provê operações básicas para implementar um circulo: 

inserir na lista OK 
retirar da lista 
mover de posição 
inserir estilo 
insere no relatório 
*/



/*
    Cria um Item com as características de um círculo 
*/
Circulo criaCirculo(double x, double y, double raio, int i, char corb[], char corp[]);


/*
    Retorna o raio do círculo circle
*/
double getRaio(Circulo circle);


/*
    Retorna a cor da borda do círculo circle 
*/
char *getCorbCircle(Circulo circle);


/*
    Retorna a cor do preenchimento do círculo circle 
*/
char *getCorpCircle(Circulo circle);


/*
    Retornam as posições X e Y do círculo circle 
*/
double getPosicXCircle(Circulo circle);
double getPosicYCircle(Circulo circle);




void moveCirculo(Circulo circle, double xAntigo, double yAntigo, double dx, double dy);


int getIdentificadorCirculo(Circulo circle);







#endif