#ifndef _LINHA_H
#define _LINHA_H

#include <stdbool.h>


typedef void *Linha;


/*
Este "contrato" provê operações básicas para implementar um Linha: 
*/



/*
    Cria um Item com as características de uma linha 
*/
Linha criaLinha(double x1, double y1, double x2, double y2, int i, char *cor);



/*
    Retorna a cor da linha line 
*/
char *getCorLine(Linha line);


/*
    Retorna o identificador da linha line 
*/
int getIdentificadorLine(Linha line);


/*
    Retornam as posições X1, Y1, X2 e Y2 da linha line 
*/
double getPosicX1Line(Linha line);
double getPosicY1Line(Linha line);
double getPosicX2Line(Linha line);
double getPosicY2Line(Linha line);



void moveLinha(Linha line, double x1Antigo, double y1Antigo, double x2Antigo, double y2Antigo, double dx, double dy);

#endif